$(document).ready(function() {
    $("#start-button").click(function() {
      $("#animated-paragraph").css({
        "width": "400px",
        "font-size": "24px",
        "border-width": "4px"
      });
    });
  
    $("#reset-button").click(function() {
      $("#animated-paragraph").css({
        "width": "200px",
        "font-size": "16px",
        "border-width": "2px"
      });
    });
  });
  